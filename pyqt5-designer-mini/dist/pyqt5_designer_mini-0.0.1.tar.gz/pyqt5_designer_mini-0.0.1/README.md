# pyqt5_designer_mini

[![PyPI - Version](https://img.shields.io/pypi/v/pyqt5-designer-mini.svg)](https://pypi.org/project/pyqt5-designer-mini)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyqt5-designer-mini.svg)](https://pypi.org/project/pyqt5-designer-mini)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pyqt5-designer-mini
```

## License

`pyqt5-designer-mini` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
