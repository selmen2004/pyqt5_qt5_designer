# SPDX-FileCopyrightText: 2024-present Selmen Arous <selmen.arous@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
